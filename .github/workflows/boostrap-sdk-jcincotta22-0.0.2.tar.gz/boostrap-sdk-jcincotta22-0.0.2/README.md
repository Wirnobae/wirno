# Python sdk boilerplate code

Use this link as a resource when publishing packages:
https://packaging.python.org/en/latest/tutorials/packaging-projects/

This is a basic example of an api sdk use the deck of cards api
https://deckofcardsapi.com/

